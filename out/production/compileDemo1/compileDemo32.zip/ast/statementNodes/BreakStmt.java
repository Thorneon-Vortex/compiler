package ast.statementNodes;
import ast.Statement;

// ast/BreakStmt.java
public class BreakStmt extends Statement {
    public BreakStmt(int lineNum) { super(lineNum); }
}