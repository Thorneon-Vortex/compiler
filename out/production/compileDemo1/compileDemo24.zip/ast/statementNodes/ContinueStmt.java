package ast.statementNodes;
import ast.Statement;

// ast/ContinueStmt.java
public class ContinueStmt extends Statement {
    public ContinueStmt(int lineNum) { super(lineNum); }
}