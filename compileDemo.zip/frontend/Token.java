package frontend;

public record Token(TokenType type, String value, int lineNum) {}
